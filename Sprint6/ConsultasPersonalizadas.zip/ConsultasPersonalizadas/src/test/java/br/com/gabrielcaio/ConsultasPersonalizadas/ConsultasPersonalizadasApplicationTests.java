package br.com.gabrielcaio.ConsultasPersonalizadas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsultasPersonalizadasApplicationTests {

	@Test
	void contextLoads() {
	}

}
